# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.apps import AppConfig


class EncuestaConfig(AppConfig):
    name = 'encuesta'
    icon = '<i class="material-icons">content_paste</i>'
