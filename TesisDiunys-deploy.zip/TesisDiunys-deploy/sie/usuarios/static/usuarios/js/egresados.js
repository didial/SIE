$(document).ready(function() {
    $(".right-panel").prepend('<div class="card"><div class="card-content"><a href="/dashboard/usuarios/egresado/import/" class="btn btn-primary import">Importar egresados</a></div></div>');
    $('select').material_select();
    console.log("ellll");
});
